/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FactoryMethod;

/**
 *
 * @author itsta
 */


import java.util.ArrayList;

public class Demo {

    public static void main(String[] args) {
        ArrayList<Shape> shapes = new ArrayList<>();

        ShapeFactory shapeFactory = new ShapeFactory();

        shapes.add(shapeFactory.createShape("circle"));
        shapes.add(shapeFactory.createShape("square"));
        shapes.add(shapeFactory.createShape("square"));
        shapes.add(shapeFactory.createShape("triangle"));

        for (Shape s : shapes) {
            s.draw();
        }
    }
}
